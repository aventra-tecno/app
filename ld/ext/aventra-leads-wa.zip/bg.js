// Aventra Leads · Ekstensi WhatsApp · background (login, token, panggilan ke Supabase)
import { SUPABASE_URL, SUPABASE_KEY } from './config.js';

const get = (k) => chrome.storage.local.get(k);
const set = (o) => chrome.storage.local.set(o);
const H = (token) => ({ apikey: SUPABASE_KEY, 'Content-Type': 'application/json', ...(token ? { Authorization: `Bearer ${token}` } : {}) });

async function authCall(path, body) {
  const r = await fetch(`${SUPABASE_URL}/auth/v1/${path}`, { method: 'POST', headers: H(), body: JSON.stringify(body) });
  const j = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(j.error_description || j.msg || j.message || 'Gagal masuk');
  return j;
}
async function saveSession(j) {
  await set({ sess: { access: j.access_token, refresh: j.refresh_token, exp: Math.floor(Date.now() / 1000) + (j.expires_in || 3600), email: j.user?.email } });
}
async function token() {
  const { sess } = await get('sess');
  if (!sess) throw new Error('Belum masuk. Klik ikon Aventra Leads di toolbar Chrome.');
  if (sess.exp - 90 > Date.now() / 1000) return sess.access;
  try { await saveSession(await authCall('token?grant_type=refresh_token', { refresh_token: sess.refresh })); }
  catch { await chrome.storage.local.remove('sess'); throw new Error('Sesi habis, silakan masuk lagi.'); }
  return (await get('sess')).sess.access;
}
async function rest(path, opt = {}) {
  const r = await fetch(`${SUPABASE_URL}/rest/v1/${path}`, { ...opt, headers: { ...H(await token()), ...(opt.headers || {}) } });
  const j = await r.json().catch(() => null);
  if (!r.ok) throw new Error(j?.message || `Error ${r.status}`);
  return j;
}
const rpc = (fn, args) => rest(`rpc/${fn}`, { method: 'POST', body: JSON.stringify(args) });

async function sendLead(id) {
  await fetch(`${SUPABASE_URL}/functions/v1/lead`, { method: 'POST', headers: H(await token()), body: JSON.stringify({ lead_id: id }) });
}

async function handle(m) {
  switch (m.t) {
    case 'login': await saveSession(await authCall('token?grant_type=password', { email: m.email, password: m.password })); return { ok: true };
    case 'logout': await chrome.storage.local.remove(['sess', 'tenant', 'status']); return { ok: true };
    case 'session': { const { sess, tenant, aktif, setuju } = await get(['sess', 'tenant', 'aktif', 'setuju']); return { email: sess?.email || null, tenant: tenant || null, aktif: aktif !== false, setuju: !!setuju }; }
    case 'setuju': await set({ setuju: !!m.on }); return { ok: true };
    case 'tenants': return rest('tenants?select=id,nama,prefix&order=created_at');
    case 'pilih': await set({ tenant: m.tenant, status: null }); return { ok: true };
    case 'aktif': await set({ aktif: !!m.on }); return { ok: true };
    case 'status': {
      const { tenant, aktif, setuju } = await get(['tenant', 'aktif', 'setuju']);
      if (!tenant || !setuju) return { tenant: null };
      const st = await rpc('ext_status', { p_tenant: tenant.id });
      await set({ status: st });
      return { tenant, aktif: aktif !== false, ...st };
    }
    case 'catat': {
      const { tenant, setuju } = await get(['tenant', 'setuju']);
      if (!setuju) throw new Error('Belum menyetujui pemrosesan data');
      const r = await rpc('ext_catat', { p_tenant: tenant.id, p_kode: m.kode, p_phone: m.phone || '', p_nama: m.nama || '', p_my_phone: m.my || '' });
      // chat baru dari klik iklan → kirim event Lead ke Meta (server yang memutuskan kirim/lewati)
      if (r?.lead?.id && !r.lead.lead_sent_at) sendLead(r.lead.id).catch(() => {});
      return r;
    }
    case 'cari': { const { tenant } = await get('tenant'); return rpc('ext_cari', { p_tenant: tenant.id, p_phone: m.phone }); }
    case 'ubah': return rpc('ext_ubah', { p_lead: m.lead, p_stage: m.stage, p_alasan: m.alasan ?? null });
    case 'lunas': {
      const r = await fetch(`${SUPABASE_URL}/functions/v1/convert`, { method: 'POST', headers: H(await token()), body: JSON.stringify({ lead_id: m.lead, nilai: m.nilai }) });
      const j = await r.json().catch(() => ({}));
      if (!r.ok) throw new Error(j.error || 'Gagal menandai lunas');
      return j;
    }
    default: throw new Error('perintah tidak dikenal');
  }
}

chrome.runtime.onMessage.addListener((m, _s, reply) => {
  handle(m).then((data) => reply({ ok: true, data }), (e) => reply({ ok: false, error: e.message }));
  return true; // balasan asinkron
});
