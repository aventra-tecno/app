/*! Aventra Leads · Ekstensi WhatsApp Web v1.1.3
 * Hanya MEMBACA chat yang tampil di WhatsApp Web. Tidak pernah mengirim pesan.
 * Yang dikirim ke Aventra hanya chat yang berisi kode promo: kode, nomor, nama, nomor WA CS. */
(() => {
  if (window.__aventraLd) return;
  window.__aventraLd = true;

  const TAHAP = { A: 'Sapa, lalu diam', B: 'Tanya harga, hilang', C: 'Bahas jadwal', D: 'Sepakat, batal', E: 'Closing' };
  const ALASAN = { 1: 'Tidak membalas', 2: 'Merasa mahal', 3: 'Di luar area', 4: 'Jadwal penuh', 5: 'Di luar menu', 6: 'Nanti dulu', 7: 'Minta terapis tertentu', 8: 'Lainnya' };
  const ALPHA = '[ABCDEFGHJKLMNPQRSTUVWXYZ23456789]{6}';
  const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const rp = (n) => 'Rp' + Number(n || 0).toLocaleString('id-ID');

  const send = (m) => new Promise((res) => {
    try { chrome.runtime.sendMessage(m, (r) => res(r || { ok: false, error: chrome.runtime.lastError?.message || 'tidak ada balasan' })); }
    catch (e) { res({ ok: false, error: e.message }); }
  });

  let cfg = null, re = null, warned = false, store = {}, storeKey = '';
  const done = new Map();          // kode -> { status, lead, iklan, phone }
  const byPhone = new Map();       // nomor -> { t, lead, iklan } (cache Pro)

  // ---------------------------------------------------------------- pengaturan
  async function loadCfg() {
    const r = await send({ t: 'status' });
    if (!r.ok || !r.data?.tenant) { cfg = null; drawPanel(); return; }
    cfg = r.data;
    re = new RegExp(`\\b${cfg.prefix}-${ALPHA}\\b`, 'g');
    storeKey = 'done_' + cfg.tenant.id;
    const s = await chrome.storage.local.get(storeKey);
    store = s[storeKey] || {};
    Object.entries(store).forEach(([k, v]) => { if (!done.has(k)) done.set(k, v); });
    scan();
  }
  const persist = () => {
    const keys = Object.keys(store);
    if (keys.length > 3000) keys.slice(0, keys.length - 3000).forEach((k) => delete store[k]);
    chrome.storage.local.set({ [storeKey]: store });
  };

  // ---------------------------------------------------------------- baca WhatsApp Web
  const myPhone = () => {
    try {
      const v = (localStorage.getItem('last-wid-md') || localStorage.getItem('last-wid') || '').replace(/"/g, '');
      const m = v.match(/^(\d{8,15})/); return m ? m[1] : '';
    } catch { return ''; }
  };
  const jidPhone = (jid) => { const m = /^(\d{8,15})@c\.us$/.exec(jid || ''); return m ? m[1] : ''; };
  const asPhone = (s) => { const d = String(s || '').replace(/[\s\-().]/g, ''); return /^\+?\d{9,15}$/.test(d) ? d.replace('+', '') : ''; };

  function openChat() {
    const main = document.querySelector('#main');
    if (!main) return null;
    const header = main.querySelector('header');
    const nameEl = header && (header.querySelector('span[dir="auto"][title]') || header.querySelector('span[dir="auto"]'));
    const name = nameEl ? (nameEl.getAttribute('title') || nameEl.textContent || '').trim() : '';
    let phone = '', group = false;
    const codes = new Set();
    // nomor & grup dari data-id (format lama/baru: false_628xx@c.us_ID, false_xxx@lid_ID, true_...)
    main.querySelectorAll('[data-id]').forEach((el) => {
      const parts = (el.getAttribute('data-id') || '').split('_');
      if (parts.length < 2) return;
      const jid = parts[1];
      if (jid.endsWith('@g.us')) group = true;
      if (!phone) phone = jidPhone(jid);
    });
    // cari kode di SEMUA teks chat (tahan terhadap perubahan tampilan WhatsApp Web),
    // kecuali judul chat, kotak ketik, dan pesan yang dikirim CS sendiri
    const skip = 'header, footer, [contenteditable="true"], .message-out, [data-id^="true_"]';
    const walker = document.createTreeWalker(main, NodeFilter.SHOW_TEXT, {
      acceptNode: (n) => (n.nodeValue && n.nodeValue.length >= 9 && !n.parentElement?.closest(skip) ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_REJECT),
    });
    for (let n = walker.nextNode(); n; n = walker.nextNode()) (n.nodeValue.match(re) || []).forEach((k) => codes.add(k));
    if (!phone) phone = asPhone(name);
    return { name: asPhone(name) ? '' : name, phone, codes: [...codes], group, key: phone || name };
  }

  // Daftar chat di kiri: cari kode di SEMUA teks & judul (tahan perubahan tampilan), lalu cari baris chat-nya
  function listRows() {
    const pane = document.querySelector('#pane-side') || document.querySelector('[aria-label*="chat" i][role="grid"], [aria-label*="chat" i][role="list"]');
    if (!pane) return [];
    const rowOf = (el) => {
      const r = el.closest('[role="listitem"], [role="row"], [role="gridcell"]');
      if (r && pane.contains(r)) return r;
      let cur = el;                                    // cadangan: naik sampai seukuran satu baris chat
      while (cur.parentElement && cur.parentElement !== pane && cur.parentElement.getBoundingClientRect().height < 110) cur = cur.parentElement;
      return cur;
    };
    const rows = new Map();
    const take = (el, txt) => {
      const ks = (txt || '').match(re);
      if (!ks) return;
      const row = rowOf(el);
      const r = rows.get(row) || { row, codes: new Set() };
      ks.forEach((k) => r.codes.add(k));
      rows.set(row, r);
    };
    const w = document.createTreeWalker(pane, NodeFilter.SHOW_TEXT);
    for (let n = w.nextNode(); n; n = w.nextNode()) if (n.nodeValue && n.nodeValue.length >= 9) take(n.parentElement, n.nodeValue);
    pane.querySelectorAll('[title]').forEach((el) => take(el, el.getAttribute('title')));
    return [...rows.values()].map(({ row, codes }) => {
      // nama = judul pertama di baris yang bukan cuplikan pesan
      const ada = new RegExp(re.source);              // tanpa flag g, aman untuk test()
      const n = [...row.querySelectorAll('span[title], [title]')].map((e) => (e.getAttribute('title') || '').trim()).find((x) => x && !ada.test(x)) || '';
      return { name: asPhone(n) ? '' : n, phone: asPhone(n), codes: [...codes] };
    });
  }

  // ---------------------------------------------------------------- catat ke Aventra
  async function catat(kode, phone, nama) {
    const prev = done.get(kode);
    if (prev?.pending) return prev;
    // kirim ulang hanya bila ada data baru: nomor yang tadinya kosong, atau nama kontak yang berubah (disimpan CS)
    if (prev && prev.status !== 'kuota_habis' && (prev.phone || !phone) && (!nama || prev.nama === nama)) return prev;
    done.set(kode, { ...(prev || {}), pending: true });
    const r = await send({ t: 'catat', kode, phone, nama, my: myPhone() });
    if (!r.ok) { prev ? done.set(kode, prev) : done.delete(kode); return null; }
    const d = r.data;
    if (d.status === 'kuota_habis') {
      done.delete(kode);
      if (!warned) { warned = true; toast(`Kuota Gratis ${d.kuota} chat/bulan sudah habis. Upgrade Pro untuk lanjut mencatat otomatis.`, 'warn', 8000); }
      return null;
    }
    const rec = { status: d.status, lead: d.lead || null, iklan: d.iklan || null, phone: !!(phone || d.lead?.phone), nama: nama || d.lead?.nama || '' };
    done.set(kode, rec);
    store[kode] = { status: rec.status, phone: rec.phone, nama: rec.nama };
    persist();
    if (d.status === 'ada' && prev?.nama && nama && prev.nama !== nama) toast(`Nama diperbarui: <b>${esc(nama)}</b>`, 'ok', 2500);
    if (d.status === 'baru') toast(`<b>${esc(kode)}</b> tercatat${d.iklan ? ` · ${esc(d.iklan)}` : ''}`, 'ok');
    return rec;
  }

  let busy = false;
  async function scan() {
    if (busy || !cfg || !re || cfg.aktif === false) { drawPanel(); return; }
    busy = true;
    try {
      const chat = openChat();
      if (chat && !chat.group) for (const k of chat.codes) await catat(k, chat.phone, chat.name);
      for (const row of listRows()) for (const k of row.codes) await catat(k, row.phone, row.name);
      await currentLead(chat);
    } finally { busy = false; }
    drawPanel();
  }

  // lead untuk chat yang sedang dibuka
  let cur = null; // { key, name, phone, lead, iklan, kode }
  async function currentLead(chat) {
    if (!chat || chat.group) { cur = null; return; }
    let lead = null, iklan = null, kode = null;
    for (const k of chat.codes) { const d = done.get(k); if (d?.lead) { lead = d.lead; iklan = d.iklan; kode = k; } }
    if (!lead && cfg.plan === 'pro' && chat.phone) {
      const c = byPhone.get(chat.phone);
      if (c && Date.now() - c.t < 60000) ({ lead, iklan } = c);
      else {
        const r = await send({ t: 'cari', phone: chat.phone });
        if (r.ok && r.data.status === 'ada') { lead = r.data.lead; iklan = r.data.iklan; }
        byPhone.set(chat.phone, { t: Date.now(), lead, iklan });
      }
    }
    if (cur?.lead && lead && cur.lead.id === lead.id) lead = { ...lead, ...cur.lead }; // pertahankan perubahan lokal
    cur = { key: chat.key, name: chat.name, phone: chat.phone, lead, iklan, kode: kode || (chat.codes[0] || null) };
  }

  // ---------------------------------------------------------------- tampilan
  function toast(html, kind = 'ok', ms = 3800) {
    const t = document.createElement('div');
    t.className = `avl-toast ${kind}`;
    t.innerHTML = `<span class="avl-dot"></span><div>${html}</div>`;
    document.body.appendChild(t);
    requestAnimationFrame(() => t.classList.add('show'));
    setTimeout(() => { t.classList.remove('show'); setTimeout(() => t.remove(), 400); }, ms);
  }

  let panel, collapsed = false, lastDraw = '';
  function drawPanel() {
    if (!panel) {
      panel = document.createElement('div');
      panel.className = 'avl-panel';
      document.body.appendChild(panel);
      panel.addEventListener('click', onClick);
      panel.addEventListener('change', onChange);
      panel.addEventListener('input', (e) => {
        if (e.target.name !== 'nilai') return;
        const d = e.target.value.replace(/\D/g, ''); e.target.value = d ? Number(d).toLocaleString('id-ID') : '';
      });
    }
    const pro = cfg?.plan === 'pro';
    let body;
    if (!cfg) body = '<div class="avl-muted">Klik ikon <b>Aventra Leads</b> di toolbar Chrome untuk memberi izin &amp; masuk.</div>';
    else if (cfg.aktif === false) body = '<div class="avl-muted">Catat otomatis sedang <b>dimatikan</b>.</div>';
    else if (!cur) body = `<div class="avl-muted">Memantau chat berkode <b>${esc(cfg.prefix)}-…</b></div>`;
    else if (!cur.lead) body = `<div class="avl-who"><b>${esc(cur.name || cur.phone || 'Chat ini')}</b></div><div class="avl-muted">Belum ada kode promo di chat ini.</div>`;
    else {
      const l = cur.lead, paid = !!l.paid_at;
      body = `<div class="avl-who"><b>${esc(l.nama || cur.name || l.phone || 'Pelanggan')}</b><small>${esc(l.phone ? '+' + l.phone : '')}</small></div>
        <div class="avl-tags">${cur.kode ? `<span class="avl-code">${esc(cur.kode)}</span>` : ''}${cur.iklan ? `<span class="avl-ad">${esc(cur.iklan)}</span>` : ''}</div>
        ${paid ? `<div class="avl-paid">✓ Lunas ${rp(l.nilai)} · Purchase dikirim ke Meta</div>` : pro ? `
          <div class="avl-lbl">Tahap</div>
          <div class="avl-stages">${['A', 'B', 'C', 'D'].map((s) => `<button data-stage="${s}" class="${l.stage === s ? 'on' : ''}" title="${TAHAP[s]}">${s}</button>`).join('')}</div>
          <div class="avl-sub">${esc(TAHAP[l.stage] || '')}</div>
          <select name="alasan"><option value="">Alasan belum closing…</option>${Object.entries(ALASAN).map(([k, v]) => `<option value="${k}" ${String(l.alasan) === k ? 'selected' : ''}>${v}</option>`).join('')}</select>
          <div class="avl-pay"><input name="nilai" inputmode="numeric" placeholder="Nilai order, mis. 135.000"><button data-act="lunas">Lunas</button></div>`
        : `<div class="avl-ok">✓ Tercatat otomatis di Aventra</div>
          <div class="avl-lock">🔒 <b>Pro</b>: ubah tahap A–D, alasan, dan tandai <b>Lunas</b> langsung dari chat ini.</div>`}`;
    }
    const html = `<div class="avl-head"><span class="avl-logo"></span><b>Aventra Leads</b>${cfg ? `<span class="avl-plan ${pro ? 'pro' : ''}">${pro ? 'PRO' : 'GRATIS'}</span>` : ''}
      ${cfg ? `<button class="avl-min" data-act="pindai" title="Pindai seluruh daftar chat">${pindai ? '…' : '⟳'}</button>` : ''}
      <button class="avl-min" data-act="min" title="Kecilkan">${collapsed ? '▴' : '▾'}</button></div>
      ${collapsed ? '' : `<div class="avl-body">${body}</div>`}`;
    if (html === lastDraw) return;
    // jangan ganggu saat CS sedang mengetik nilai
    if (panel.contains(document.activeElement) && document.activeElement.name === 'nilai') return;
    lastDraw = html;
    panel.innerHTML = html;
    panel.classList.toggle('mini', collapsed);
  }

  async function onClick(e) {
    const b = e.target.closest('button'); if (!b) return;
    if (b.dataset.act === 'min') { collapsed = !collapsed; lastDraw = ''; drawPanel(); return; }
    if (b.dataset.act === 'pindai') { pindaiSemua(); return; }
    if (!cur?.lead) return;
    if (b.dataset.stage) {
      const r = await send({ t: 'ubah', lead: cur.lead.id, stage: b.dataset.stage, alasan: cur.lead.alasan ?? null });
      if (!r.ok) return toast(esc(r.error), 'err');
      cur.lead = { ...cur.lead, ...r.data }; lastDraw = ''; drawPanel(); toast(`Tahap diubah ke <b>${b.dataset.stage}</b>`, 'ok', 2000);
    }
    if (b.dataset.act === 'lunas') {
      const nilai = Number((panel.querySelector('[name=nilai]')?.value || '').replace(/\D/g, ''));
      if (!nilai) return toast('Isi nilai order dulu', 'warn');
      if (!confirm(`Tandai lunas ${rp(nilai)}? Purchase akan dikirim ke Meta.`)) return;
      b.disabled = true; b.textContent = '…';
      const r = await send({ t: 'lunas', lead: cur.lead.id, nilai });
      if (!r.ok) { b.disabled = false; b.textContent = 'Lunas'; return toast(esc(r.error), 'err'); }
      cur.lead = { ...cur.lead, paid_at: new Date().toISOString(), nilai, stage: 'E' };
      lastDraw = ''; drawPanel(); toast(`Lunas ${rp(nilai)} · Purchase terkirim ke Meta`, 'ok');
    }
  }
  async function onChange(e) {
    if (e.target.name !== 'alasan' || !cur?.lead) return;
    const r = await send({ t: 'ubah', lead: cur.lead.id, stage: cur.lead.stage === 'E' ? 'D' : cur.lead.stage, alasan: e.target.value ? Number(e.target.value) : null });
    if (!r.ok) return toast(esc(r.error), 'err');
    cur.lead = { ...cur.lead, ...r.data }; toast('Alasan disimpan', 'ok', 1800);
  }

  // Pindai seluruh daftar chat: WhatsApp Web hanya menampilkan ±20 chat sekaligus,
  // jadi daftar digulir pelan dari atas ke bawah sambil membaca cuplikan tiap chat, lalu kembali ke atas.
  let pindai = false;
  async function pindaiSemua() {
    if (pindai || !cfg) return;
    const pane = document.querySelector('#pane-side');
    if (!pane) return toast('Daftar chat tidak ditemukan', 'err');
    const box = [pane, ...pane.querySelectorAll('*')].find((e) => e.scrollHeight > e.clientHeight + 50 && /(auto|scroll)/.test(getComputedStyle(e).overflowY)) || pane;
    pindai = true; lastDraw = ''; drawPanel();
    const awal = [...done.keys()].length;
    toast('Memindai daftar chat…', 'ok', 2500);
    box.scrollTop = 0;
    for (let i = 0; i < 80; i++) {
      await new Promise((r) => setTimeout(r, 650));
      for (const row of listRows()) for (const k of row.codes) await catat(k, row.phone, row.name);
      if (box.scrollTop + box.clientHeight >= box.scrollHeight - 5) break;
      box.scrollTop += Math.max(200, box.clientHeight * 0.8);
    }
    box.scrollTop = 0;
    pindai = false; lastDraw = ''; drawPanel();
    const baru = [...done.keys()].length - awal;
    toast(`Selesai memindai. ${baru > 0 ? `<b>${baru}</b> kode baru tercatat.` : 'Tidak ada kode baru.'}`, 'ok', 4500);
  }

  // ---------------------------------------------------------------- jalan
  let t = 0;
  const later = () => { clearTimeout(t); t = setTimeout(scan, 900); };
  new MutationObserver(later).observe(document.body, { childList: true, subtree: true, characterData: true });
  chrome.storage.onChanged.addListener((ch) => { if (ch.tenant || ch.aktif || ch.sess || ch.setuju) loadCfg(); });
  setInterval(loadCfg, 5 * 60 * 1000);
  setInterval(scan, 15000);
  loadCfg();
})();
