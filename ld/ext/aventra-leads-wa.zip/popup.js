// Aventra Leads · popup ekstensi: masuk, pilih bisnis, paket & kuota
import { APP_URL, EXT_VERSION } from './config.js';

const send = (m) => new Promise((res, rej) => chrome.runtime.sendMessage(m, (r) => (r?.ok ? res(r.data) : rej(new Error(r?.error || 'Gagal')))));
const app = document.getElementById('app');
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const head = (sub) => `<div class="head"><b><img src="icons/48.png" alt="">Aventra Leads</b><small>${sub}</small></div>`;

async function main() {
  const s = await send({ t: 'session' }).catch(() => ({}));
  if (!s.setuju) return setuju(s);
  if (!s.email) return login();
  if (!s.tenant) return pilih(s);
  return status(s);
}

// Persetujuan data (wajib sebelum ekstensi membaca WhatsApp Web)
function setuju(s) {
  app.innerHTML = `${head('Sebelum mulai: izin pemrosesan data')}
  <div class="body">
    <div class="card"><b>Yang dilakukan ekstensi ini</b>
      <ul class="consent">
        <li><b>Membaca</b> daftar chat dan chat yang sedang dibuka di WhatsApp Web, hanya untuk mencari kode promo dari iklan Anda (mis. <code>MR-K7M2QX</code>).</li>
        <li>Untuk chat yang berisi kode itu saja, mengirim ke akun Aventra Leads Anda: <b>kode, nomor WA &amp; nama pelanggan, nomor WA CS, waktu</b>.</li>
        <li><b>Tidak</b> menyimpan atau mengirim isi percakapan lain, dan <b>tidak pernah</b> mengirim pesan WhatsApp.</li>
        <li>Data dipakai untuk laporan iklan Anda dan, bila diaktifkan, dikirim ke Pixel/Meta milik bisnis Anda (Lead &amp; Purchase).</li>
      </ul>
      <a href="${APP_URL}privasi-ekstensi.html" target="_blank">Baca kebijakan privasi lengkap</a>
    </div>
    <label class="switch" style="gap:10px"><span>Saya mengerti dan setuju</span><input type="checkbox" id="ok"></label>
    <button class="pri" id="go" disabled>Setuju &amp; lanjut</button>
  </div>`;
  const ok = document.getElementById('ok'), go = document.getElementById('go');
  ok.onchange = () => { go.disabled = !ok.checked; };
  go.onclick = async () => { await send({ t: 'setuju', on: true }); main(); };
}

function login(err = '') {
  app.innerHTML = `${head('Catat otomatis chat berkode dari WhatsApp Web')}
  <form class="body" id="f">
    <label>Email<input name="email" type="email" required autocomplete="email"></label>
    <label>Password<input name="password" type="password" required autocomplete="current-password"></label>
    ${err ? `<div class="err">${esc(err)}</div>` : ''}
    <button class="pri">Masuk</button>
    <div class="muted">Pakai akun yang sama dengan <a href="${APP_URL}" target="_blank">app.aventra.id</a>.</div>
  </form>`;
  const f = document.getElementById('f');
  f.onsubmit = async (e) => {
    e.preventDefault();
    try { await send({ t: 'login', email: f.email.value.trim(), password: f.password.value }); main(); }
    catch (x) { login(x.message === 'Invalid login credentials' ? 'Email atau password salah' : x.message); }
  };
}

async function pilih(s) {
  app.innerHTML = `${head(esc(s.email))}<div class="body"><div class="muted">Memuat bisnis…</div></div>`;
  try {
    const list = await send({ t: 'tenants' });
    if (list.length === 1) { await send({ t: 'pilih', tenant: list[0] }); return main(); }
    app.innerHTML = `${head(esc(s.email))}<div class="body">
      <label>Pilih bisnis<select id="t">${list.map((t, i) => `<option value="${i}">${esc(t.nama)} (${esc(t.prefix)})</option>`).join('')}</select></label>
      <button class="pri" id="ok">Pakai bisnis ini</button><button class="ghost" id="out">Keluar</button></div>`;
    document.getElementById('ok').onclick = async () => { await send({ t: 'pilih', tenant: list[document.getElementById('t').value] }); main(); };
    document.getElementById('out').onclick = async () => { await send({ t: 'logout' }); main(); };
  } catch (x) { app.innerHTML = `${head(esc(s.email))}<div class="body"><div class="err">${esc(x.message)}</div></div>`; }
}

async function status(s) {
  app.innerHTML = `${head(esc(s.tenant.nama))}<div class="body"><div class="muted">Memuat…</div></div>`;
  let st;
  try { st = await send({ t: 'status' }); } catch (x) { app.innerHTML = `${head(esc(s.tenant.nama))}<div class="body"><div class="err">${esc(x.message)}</div><button class="ghost" id="out">Keluar</button></div>`; document.getElementById('out').onclick = async () => { await send({ t: 'logout' }); main(); }; return; }
  const pro = st.plan === 'pro', pct = Math.min(100, Math.round(st.terpakai / st.kuota * 100));
  app.innerHTML = `${head(`${esc(s.email)} · kode ${esc(st.prefix)}-…`)}
  <div class="body">
    <div class="card">
      <div class="row"><b>${esc(st.nama)}</b><span class="badge ${pro ? 'pro' : 'free'}">${pro ? 'PRO' : 'GRATIS'}</span></div>
      ${pro ? `<div class="muted">Catat otomatis tanpa batas${st.plan_until ? ` · aktif sampai ${new Date(st.plan_until).toLocaleDateString('id-ID', { day: 'numeric', month: 'short', year: 'numeric' })}` : ''}</div>`
        : `<div class="row muted"><span>Chat tercatat bulan ini</span><b>${st.terpakai} / ${st.kuota}</b></div><div class="bar"><i style="width:${pct}%"></i></div>`}
    </div>
    <label class="switch">Catat otomatis di WhatsApp Web<input type="checkbox" id="on" ${s.aktif ? 'checked' : ''}></label>
    ${pro ? '' : `<div class="card up"><b>Pro: kerja CS langsung dari chat</b><ul>
      <li>Catat otomatis tanpa batas</li><li>Panel di samping chat: tahap A–D & alasan</li><li>Tandai Lunas + nilai → Purchase ke Meta</li></ul>
      <div class="muted">Hubungi admin Aventra untuk upgrade.</div></div>`}
    <a class="ghost" style="display:grid;place-items:center;height:40px;border-radius:11px;border:1.5px solid #E2E9E5" href="https://web.whatsapp.com/" target="_blank">Buka WhatsApp Web</a>
    <div class="foot"><a href="${APP_URL}" target="_blank">Dashboard</a><a href="#" id="cabut">Cabut izin</a><span class="muted">v${EXT_VERSION}</span><a href="#" id="ganti">Ganti bisnis</a><a href="#" id="out">Keluar</a></div>
  </div>`;
  document.getElementById('on').onchange = (e) => send({ t: 'aktif', on: e.target.checked });
  document.getElementById('cabut').onclick = async (e) => { e.preventDefault(); if (!confirm('Cabut izin? Ekstensi berhenti membaca WhatsApp Web.')) return; await send({ t: 'setuju', on: false }); main(); };
  document.getElementById('ganti').onclick = async (e) => { e.preventDefault(); await send({ t: 'pilih', tenant: null }); main(); };
  document.getElementById('out').onclick = async (e) => { e.preventDefault(); await send({ t: 'logout' }); main(); };
}

main();
