// Aventra Leads · Ekstensi WhatsApp · koneksi (hanya publishable key, aman di sini)
export const SUPABASE_URL = 'https://ydpyiwrznodxskpcwfcr.supabase.co';
export const SUPABASE_KEY = 'sb_publishable_UYQMNd2FcKM6teFf_3AVfA_NnyZyJbu';
export const APP_URL = 'https://app.aventra.id/app/ld/';
export const EXT_VERSION = '1.1.0';
